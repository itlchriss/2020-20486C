﻿
using day2demo.Models;
using System.Web.Mvc;

namespace day2demo.Controllers
{
    public class PersonalController : Controller
    {
        public ActionResult Index()
        {
            //Dictionary<string, object> dict = 
            //    new Dictionary<string, object>();
            object tmp;
            Personal data = new Personal();
            if (!TempData.TryGetValue("personal", out tmp))
            {
                data.zhName = "甲乙丙";
                data.enName = "ABC";
                data.phone = "12345678";
                data.address = "SomewhereYoudontknow";
            }
            else
            {
                data = tmp as Personal;
            }
            return View(data);
        }
    }
}