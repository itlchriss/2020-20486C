﻿using day2demo.Models;
using System.Collections.Generic;
using System.Web.Mvc;


namespace day2demo.Controllers
{
    public class EducationController : Controller
    {
        public ActionResult Index()
        {            
            List<Education> educations = HttpContext.Session["educations"] as List<Education>;
            if (educations == null || educations.Count <= 0)
            {
                educations = new List<Education>();
                educations.Add(
                    new Education
                    {
                        id = 1,
                        school = "NCTU",
                        subject = "CS - MS",
                        period = "2013",
                    }
                );
                educations.Add(
                    new Education
                    {
                        id = 2,
                        school = "NCTU",
                        subject = "CS - BS",
                        period = "2011"
                    });
                HttpContext.Session["educations"] = educations;
            }
            return View(educations);
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Update(int id)
        {
            List<Education> educations = 
                HttpContext.Session["educations"] as List<Education>;
            Education education = new Education();
            foreach (Education e in educations)
            {
                if (e.id == id)
                {
                    education.id = id;
                    education.period = e.period;
                    education.school = e.school;
                    education.subject = e.subject;
                }
            }
            //ViewBag.id = id;
            return View(education);
        }

        [HttpPost]
        public ActionResult DoUpdate(Education education)
        {
            //TODO: what if the target id is not found
            List<Education> educations = HttpContext.Session["educations"] as List<Education>;
            for (int i = 0; i < educations.Count; ++i)
            {
                if (educations[i].id == education.id)
                {
                    educations[i].id = education.id;
                    educations[i].period = education.period;
                    educations[i].school = education.school;
                    educations[i].subject = education.subject;
                    break;
                }
            }
            HttpContext.Session["educations"] = educations;
            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult DoCreate(Education education)
        {
            List<Education> educations = HttpContext.Session["educations"] as List<Education>;
            education.id = educations.Count + 1;
            educations.Add(education);
            HttpContext.Session["educations"] = educations;
            return RedirectToAction("Index");
        }
    }
}