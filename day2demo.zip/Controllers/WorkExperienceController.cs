﻿
using System.Web.Mvc;

namespace day2demo.Controllers
{
    public class WorkExperienceController : Controller
    {
    }
}