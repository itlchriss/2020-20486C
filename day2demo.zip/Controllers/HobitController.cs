﻿using day2demo.Models;
using System.Collections.Generic;
using System.Web.Mvc;

namespace day2demo.Controllers
{
    public class HobitController : Controller
    {
        public ActionResult Index()
        {
            List<Hobit> hobits = new List<Hobit>();
            TempData["hobits"] = hobits;
            return View();
        }

        public ActionResult Update()
        {
            return View();
        }

        
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult DoCreate(Hobit hobit)
        {
            var hobits = TempData["hobits"] as List<Hobit>;
            hobits.Add(hobit);
            TempData["hobits"] = hobits;
            return View();
        }
    }
}