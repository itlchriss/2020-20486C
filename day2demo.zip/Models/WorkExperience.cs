﻿using System.ComponentModel.DataAnnotations;

namespace day2demo.Models
{
    public class WorkExperience
    {
        [Display(Name = "公司名稱")]
        public string companyName { get; set; }
        [Display(Name = "地點")]
        public string location { get; set; }
        [Display(Name = "工作內容")]
        public string responsibility { get; set; }
    }
}