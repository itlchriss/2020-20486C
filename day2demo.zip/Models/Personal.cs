﻿using System.ComponentModel.DataAnnotations;

namespace day2demo.Models
{
    public class Personal
    {
        [Display(Name = "中文名稱")]
        public string zhName { get; set; }
        [Display(Name = "英文名稱")]
        public string enName { get; set; }
        [Display(Name = "地址")]
        public string address { get; set; }
        [Display(Name = "電話")]
        public string phone { get; set; }
    }
}