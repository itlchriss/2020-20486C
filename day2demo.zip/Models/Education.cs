﻿using System.ComponentModel.DataAnnotations;

namespace day2demo.Models
{
    public class Education
    {     
        public int id { get; set; }
        [Display(Name = "機構名稱")]
        public string school { get; set; }
        [Display(Name = "課程名稱")]
        public string subject { get; set; }
        [Display(Name = "修讀期間")]
        public string period { get; set; }
    }
}