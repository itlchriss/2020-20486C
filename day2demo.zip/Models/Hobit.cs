﻿using System.ComponentModel.DataAnnotations;

namespace day2demo.Models
{
    public class Hobit
    {
        [Display(Name = "名稱")]
        public string name { get; set; }
        [Display(Name = "週末娛樂")]
        public bool weekday { get; set; }
        [Display(Name = "類型")]
        public string hobitType { get; set; }
    }
}