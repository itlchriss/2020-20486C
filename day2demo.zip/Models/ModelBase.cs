﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web;
using System.Web.Mvc;

namespace day2demo.Models
{
    //public static class ModelBase
    //{
    //    public static string GetDisplayName<TModel, TProperty>(
    //        this TModel model,
    //        Expression<Func<TModel, TProperty>> expression)
    //    {
    //        return ModelMetadata.FromLambdaExpression<TModel, TProperty>(
    //            expression,
    //            new ViewDataDictionary<TModel>(model).Dis
    //            );
    //    }
    //}
}